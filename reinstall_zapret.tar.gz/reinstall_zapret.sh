#!/bin/bash

# Функция для запроса пароля sudo
get_sudo_access() {
    if ! sudo -n true 2>/dev/null; then
        while true; do
            local password
            password=$(zenity --password --title="Требуются права администратора" --text="Введите пароль для установки Zapret DPI Manager:")

            # Проверяем, была ли нажата отмена
            if [ $? -ne 0 ]; then
                zenity --info --title="Отменено" --text="Установка Zapret DPI Manager отменена пользователем." --width=300
                exit 0
            fi

            # Проверяем, что пароль не пустой
            if [ -z "$password" ]; then
                zenity --error --title="Ошибка" --text="Пароль не может быть пустым! Попробуйте еще раз."
                continue
            fi

            # Проверяем пароль
            if echo "$password" | sudo -S true 2>/dev/null; then
                # Пароль верный, выходим из цикла
                break
            else
                # Пароль неверный, показываем ошибку и продолжаем цикл
                zenity --error --title="Ошибка" --text="Неверный пароль! Попробуйте еще раз."
            fi
        done
    fi
}

# Функция для показа информационных сообщений
show_info() {
    zenity --info --title="Zapret DPI Manager" --text="$1" --width=300
}

# Функция для показа ошибок
show_error() {
    zenity --error --title="Ошибка" --text="$1" --width=300
}

# Функция подтверждения действия
confirm_action() {
    zenity --question \
        --title="Zapret DPI Manager" \
        --text="$1" \
        --width=400 \
        --ok-label="Продолжить" \
        --cancel-label="Отмена"
}

# Функция подтверждения с кнопками Да/Нет
confirm_yes_no() {
    zenity --question \
        --title="Zapret DPI Manager" \
        --text="$1" \
        --width=400 \
        --ok-label="Да" \
        --cancel-label="Нет"
}

# Функция проверки и обновления установщика
check_and_update_installer() {
    local installer_path="/home/deck/reinstall_zapret.sh"

    # Если файл установщика уже существует, обновляем его
    if [[ -f "$installer_path" ]]; then
        cp "$0" "$installer_path"
        chmod +x "$installer_path"
    else
        # Если установщика нет, копируем его
        cp "$0" "$installer_path"
        chmod +x "$installer_path"
    fi
}

# Функция создания бэкапа конфигурационных файлов
backup_config_files() {

    local backup_dir="/home/deck/zapret_backup"
    mkdir -p "$backup_dir"

    # Файлы для бэкапа
    local files_to_backup=(
        "/opt/zapret/autohosts.txt"
        "/opt/zapret/ignore.txt"
        "/opt/zapret/config.txt"
    )

    for file in "${files_to_backup[@]}"; do
        if [[ -f "$file" ]]; then
            sudo cp "$file" "$backup_dir/" 2>/dev/null && \
            sudo chown deck:deck "$backup_dir/$(basename "$file")" 2>/dev/null
        fi
    done

    # Бэкап папки lists
    if [[ -d "/opt/zapret/lists" ]]; then
        sudo cp -r "/opt/zapret/lists" "$backup_dir/" 2>/dev/null && \
        sudo chown -R deck:deck "$backup_dir/lists" 2>/dev/null
    fi

    return 0
}

# Функция восстановления конфигурационных файлов
restore_config_files() {

    local backup_dir="/home/deck/zapret_backup"

    if [[ -d "$backup_dir" ]]; then
        # Файлы для восстановления
        local files_to_restore=(
            "autohosts.txt:/opt/zapret/autohosts.txt"
            "ignore.txt:/opt/zapret/ignore.txt"
            "config.txt:/opt/zapret/config.txt"
        )

        for file_pair in "${files_to_restore[@]}"; do
            local backup_file="${file_pair%%:*}"
            local target_file="${file_pair##*:}"

            if [[ -f "$backup_dir/$backup_file" ]]; then
                sudo cp "$backup_dir/$backup_file" "$target_file" 2>/dev/null && \
                sudo chmod 644 "$target_file" 2>/dev/null
            fi
        done

        # Восстановление папки lists
        if [[ -d "$backup_dir/lists" ]]; then
            sudo mkdir -p "/opt/zapret/lists" 2>/dev/null
            sudo cp -r "$backup_dir/lists"/* "/opt/zapret/lists/" 2>/dev/null && \
            sudo chmod -R 644 "/opt/zapret/lists/"* 2>/dev/null
        fi

        # Удаляем папку бэкапа после восстановления
        rm -rf "$backup_dir"
    fi

    return 0
}

# Функция полного удаления (включая папку zapret)
complete_uninstall() {
    if ! confirm_yes_no "Будет выполнено ПОЛНОЕ удаление Zapret DPI Manager:\n- Служба Zapret\n- Все конфигурации\n- Папка /home/deck/zapret\n- Ярлык на рабочем столе\n\nПродолжить?"; then
        show_info "Удаление Zapret DPI Manager отменена пользователем."
        return
    fi

    # Отключение защиты от записи
    sudo steamos-readonly disable

    # Остановка и отключение службы
    sudo systemctl stop zapret 2>/dev/null
    sudo systemctl disable zapret 2>/dev/null


    # Удаление файлов службы
    sudo rm -rf /usr/lib/systemd/system/zapret.service 2>/dev/null
    sudo rm -rf /opt/zapret 2>/dev/null


    # Полное удаление папки zapret
    rm -rf /home/deck/zapret 2>/dev/null

    # Удаление пользовательских файлов и ярлыков
    rm -rf ~/Desktop/Zapret-DPI.desktop 2>/dev/null

    show_info "Zapret DPI Manager полностью удален, включая все файлы и настройки."
}

# Функция удаления только службы (для переустановки)
service_uninstall() {

    # Отключение защиты от записи
    sudo steamos-readonly disable

    # Остановка и отключение службы
    sudo systemctl stop zapret 2>/dev/null
    sudo systemctl disable zapret 2>/dev/null


    # Удаление файлов службы
    sudo rm -rf /usr/lib/systemd/system/zapret.service 2>/dev/null
    sudo rm -rf /opt/zapret 2>/dev/null


    # Удаление только ярлыка (папка zapret сохраняется)
    rm -rf ~/Desktop/Zapret-DPI.desktop 2>/dev/null

}

# Функция проверки установлен ли Zapret
is_zapret_installed() {
    # Проверяем наличие службы systemd
    if systemctl list-unit-files | grep -q zapret.service; then
        return 0  # служба найдена - установлен
    fi

    # Проверяем наличие директории /opt/zapret
    if [ -d "/opt/zapret" ]; then
        return 0  # директория найдена - установлен
    fi

    # Проверяем наличие основного скрипта
    if [ -f "/home/deck/zapret/zapret.py" ]; then
        return 0  # скрипт найден - установлен
    fi

    return 1  # ничего не найдено - не установлен
}

# Главная функция установки
install_zapret() {

    # Создание директории
    mkdir -p /home/deck/zapret
    cd /home/deck/zapret

    # Загрузка файлов
    if ! wget -q https://github.com/mashakulina/Zapret-DPI-for-Steam-Deck/releases/latest/download/zapret_dpi_manager.zip; then
        show_error "Ошибка загрузки файла!"
        exit 1
    fi

    # Распаковка архива - сначала посмотрим что в нем
    # Создаем временную директорию для распаковки
    TEMP_DIR=$(mktemp -d)

    # Распаковываем весь архив во временную директорию
    if ! unzip -q zapret_dpi_manager.zip -d "$TEMP_DIR"; then
        show_error "Ошибка распаковки архива!"
        rm -rf "$TEMP_DIR"
        exit 1
    fi

    # Проверяем, есть ли уже установщик в папке zapret
    local installer_exists=false
    if [[ -f "/home/deck/zapret/reinstall_zapret.sh" ]]; then
        installer_exists=true
    fi

    # Копируем файлы в зависимости от наличия установщика
    if [ "$installer_exists" = true ]; then
        # Если установщик уже есть - копируем только основные файлы
        find "$TEMP_DIR" -type f \( -name "zapret.py" -o -name "zapret.png" -o -name "zapret.zip" \) -exec cp {} /home/deck/zapret/ \;
    else
        # Если установщика нет - копируем все файлы включая установщик
        find "$TEMP_DIR" -type f \( -name "zapret.py" -o -name "zapret.png" -o -name "zapret.zip" -o -name "reinstall_zapret.sh" \) -exec cp {} /home/deck/zapret/ \;
    fi

    # Удаляем временную директорию
    rm -rf "$TEMP_DIR"

    # Проверяем что нужные файлы скопировались
    if [[ ! -f "/home/deck/zapret/zapret.py" ]]; then
        show_error "Файл zapret.py не найден в архиве!"
        exit 1
    fi

    # Очистка
    rm -f zapret_dpi_manager.zip
    sudo chmod +x zapret.py

    # Даем права на установщик, если он был скопирован
    if [[ -f "/home/deck/zapret/reinstall_zapret.sh" ]]; then
        chmod +x /home/deck/zapret/reinstall_zapret.sh
    fi

    # Создание ярлыка на рабочем столе
    echo "[Desktop Entry]
Type=Application
Name=Zapret DPI Manager
Exec=/usr/bin/python3 /home/deck/zapret/zapret.py
Icon=/home/deck/zapret/zapret.png
Terminal=false
Categories=Utility;" > ~/Desktop/Zapret-DPI.desktop

    chmod +x ~/Desktop/Zapret-DPI.desktop

    # Запуск приложения
    if confirm_yes_no "Установка завершена успешно!\nЗапустить Zapret DPI Manager сейчас?"; then
        cd /home/deck/zapret
        python3 zapret.py
    else
        show_info "Установка завершена!\nЯрлык приложения создан на рабочем столе."
    fi
}

# Главное меню
show_main_menu() {
    choice=$(zenity --list \
        --title="Zapret DPI Manager Installer" \
        --text="Выберите действие:" \
        --radiolist \
        --column="Выбор" \
        --column="Действие" \
        --width=500 \
        --height=250 \
        TRUE "Установка Zapret DPI Manager" \
        FALSE "Переустановка Zapret DPI Manager" \
        FALSE "Удаление Zapret DPI Manager (все файлы и настройки)")

    case $choice in
        "Установка Zapret DPI Manager")
            if confirm_yes_no "Начать установку Zapret DPI Manager?\n(Если служба уже установлена, будет предложена переустановка)"; then
                install_zapret
            else
                show_info "Установка Zapret DPI Manager отменена пользователем."
            fi
            ;;
        "Переустановка Zapret DPI Manager")
            # Проверяем, установлен ли Zapret
            if ! is_zapret_installed; then
                if confirm_yes_no "Zapret DPI Manager не обнаружен в системе.\nВыполнить первоначальную установку?"; then
                    install_zapret
                else
                    show_info "Установка Zapret DPI Manager отменена пользователем."
                fi
            else
                # Проверяем и обновляем установщик при переустановке
                check_and_update_installer
                if confirm_yes_no "Будет выполнено удаление службы и повторная установка.\nКонфигурации будут сохранены.\nПродолжить?"; then
                    # Создаем бэкап перед удалением
                    backup_config_files
                    service_uninstall
                    install_zapret
                    # Восстанавливаем конфигурации после установки
                    restore_config_files
                else
                    show_info "Переустановка Zapret DPI Manager отменена пользователем."
                fi
            fi
            ;;
        "Удаление Zapret DPI Manager (все файлы и настройки)")
            complete_uninstall
            ;;
        *)
            show_info "Установка Zapret DPI Manager отменена пользователем."
            ;;
    esac
}

# Проверка наличия zenity
if ! command -v zenity &> /dev/null; then
    echo "Zenity не установлен. Установите его командой: sudo pacman -S zenity"
    exit 1
fi

# Запрашиваем права sudo перед показом меню
get_sudo_access

# Запуск главного меню
show_main_menu
