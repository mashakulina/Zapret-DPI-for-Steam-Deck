#!/bin/bash

set -e

# === УНИВЕРСАЛЬНЫЕ ПЕРЕМЕННЫЕ ===
CURRENT_USER="$(whoami)"
CURRENT_HOME="$HOME"
SUDO_PASSWORD=""
BACKUP_CREATED=false
BACKUP_DIR=""

# === ПЕРЕМЕННЫЕ ДЛЯ РЕЖИМА ОТОБРАЖЕНИЯ ===
USE_ZENITY=true
ZENITY_INSTALLED=false

# === ФУНКЦИЯ: Установка zenity если нет ===
install_zenity_if_needed() {
    echo "Проверка наличия zenity..."

    if type zenity &> /dev/null; then
        ZENITY_INSTALLED=true
        USE_ZENITY=true
        echo "Zenity найден, используем графический интерфейс"
        return 0
    fi

    echo "Zenity не найден, пробуем установить..."
    echo ""

    # Сохраняем текущий пароль если он уже есть
    local temp_password="$SUDO_PASSWORD"

    # Если у нас еще нет пароля, запрашиваем его
    if [ -z "$temp_password" ]; then
        echo "Для установки Zenity требуются права администратора"
        echo "Введите ваш пароль sudo:"
        read -s temp_password
        echo ""

        if [ -z "$temp_password" ]; then
            echo "Пароль не введен. Пропускаем установку Zenity."
            ZENITY_INSTALLED=false
            USE_ZENITY=false
            return 1
        fi

        # Проверяем пароль
        if ! echo "$temp_password" | sudo -S true 2>/dev/null; then
            echo "Неверный пароль. Пропускаем установку Zenity."
            ZENITY_INSTALLED=false
            USE_ZENITY=false
            return 1
        fi

        # Сохраняем верный пароль
        SUDO_PASSWORD="$temp_password"
    fi

    echo "Пытаемся установить Zenity..."

    # Пробуем разные способы установки
    local installed=false

    if command -v pacman &> /dev/null; then
        echo "Пробуем установить через pacman..."
        if echo "$temp_password" | sudo -S pacman -S --noconfirm zenity 2>/dev/null; then
            installed=true
        else
            echo "Не удалось установить через pacman, пробуем другой метод..."
            # Пробуем с обновлением базы данных
            echo "$temp_password" | sudo -S pacman -Syy --noconfirm 2>/dev/null || true
            echo "$temp_password" | sudo -S pacman -S --noconfirm zenity 2>/dev/null || true
        fi
    fi

    # Проверяем другие пакетные менеджеры если pacman не сработал
    if ! $installed && command -v apt &> /dev/null; then
        echo "Пробуем установить через apt..."
        echo "$temp_password" | sudo -S apt update && \
        echo "$temp_password" | sudo -S apt install -y zenity 2>/dev/null && installed=true
    fi

    if ! $installed && command -v dnf &> /dev/null; then
        echo "Пробуем установить через dnf..."
        echo "$temp_password" | sudo -S dnf install -y zenity 2>/dev/null && installed=true
    fi

    if ! $installed && command -v zypper &> /dev/null; then
        echo "Пробуем установить через zypper..."
        echo "$temp_password" | sudo -S zypper install -y zenity 2>/dev/null && installed=true
    fi

    # Проверяем, установился ли zenity
    if type zenity &> /dev/null; then
        ZENITY_INSTALLED=true
        USE_ZENITY=true
        echo ""
        echo "Zenity успешно установлен, используем графический интерфейс"
        return 0
    else
        ZENITY_INSTALLED=false
        USE_ZENITY=false
        echo ""
        echo "Не удалось установить Zenity. Переходим в консольный режим."
        echo "Установка будет продолжена без графического интерфейса."
        echo "Нажмите Enter для продолжения..."
        read
        return 1
    fi
}

# === АДАПТИВНЫЕ ФУНКЦИИ ОТОБРАЖЕНИЯ ===
show_message() {
    local title="$1"
    local text="$2"

    if [ "$USE_ZENITY" = true ] && [ "$ZENITY_INSTALLED" = true ]; then
        # Используем printf для обработки \n символов
        local formatted_text
        formatted_text=$(printf "%b" "$text")
        zenity --info --title="$title" --text="$formatted_text" --no-markup --width=400 2>/dev/null || true
    else
        echo ""
        echo "=== $title ==="
        # В консоли \n обрабатываются автоматически
        echo -e "$text"
        echo ""
        echo "Нажмите Enter для продолжения..."
        read
    fi
}

get_password() {
    local title="$1"
    local text="$2"

    if [ "$USE_ZENITY" = true ] && [ "$ZENITY_INSTALLED" = true ]; then
        zenity --password --title="$title" --text="$text" --no-markup 2>/dev/null
    else
        echo ""
        echo ">>> $title <<<"
        echo "$text"
        read -s -p "Пароль: " password
        echo ""
        echo "$password"
    fi
}

show_error() {
    local title="$1"
    local text="$2"

    if [ "$USE_ZENITY" = true ] && [ "$ZENITY_INSTALLED" = true ]; then
        zenity --error --title="$title" --text="$text" --no-markup --width=400 2>/dev/null || true
    else
        echo ""
        echo "!!! ОШИБКА: $title !!!" >&2
        echo "$text" >&2
        echo ""
    fi
}

show_question() {
    local title="$1"
    local text="$2"
    local ok_label="${3:-OK}"
    local cancel_label="${4:-Отмена}"

    if [ "$USE_ZENITY" = true ] && [ "$ZENITY_INSTALLED" = true ]; then
        zenity --question --title="$title" --text="$text" \
               --ok-label="$ok_label" --cancel-label="$cancel_label" \
               --no-markup --width=400 --height=150 2>/dev/null
        return $?
    else
        echo ""
        echo "??? $title ???"
        echo "$text"
        echo ""
        while true; do
            read -p "($ok_label/$cancel_label) [Y/n]: " answer
            case "$answer" in
                [Yy]*|"" ) return 0 ;;
                [Nn]* ) return 1 ;;
                * ) echo "Пожалуйста, введите Y (да) или N (нет)" ;;
            esac
        done
    fi
}

show_progress() {
    local title="$1"
    local text="$2"

    if [ "$USE_ZENITY" = true ] && [ "$ZENITY_INSTALLED" = true ]; then
        zenity --progress \
               --title="$title" \
               --text="$text" \
               --percentage=0 \
               --auto-close \
               --no-cancel \
               --width=400 2>/dev/null
    else
        # Консольный режим - показываем шаги по мере их выполнения
        echo ""
        echo ">>> $title <<<"
        echo ">>> $text"
        echo ""

        # Читаем из stdin и показываем прогресс
        local line
        while IFS= read -r line; do
            if [[ "$line" =~ ^([0-9]+)$ ]]; then
                echo "Прогресс: ${BASH_REMATCH[1]}%"
            elif [[ "$line" =~ ^#[[:space:]]*(.+)$ ]]; then
                echo "> ${BASH_REMATCH[1]}"
            fi
        done

        echo ""
        echo ">>> Завершено"
        echo ""
    fi
}

# === ФУНКЦИЯ: Получение sudo доступа ===
get_sudo_access() {
    if ! sudo -n true 2>/dev/null; then
        while true; do
            if [ "$USE_ZENITY" = true ] && [ "$ZENITY_INSTALLED" = true ]; then
                SUDO_PASSWORD=$(get_password "Требуются права администратора" \
                    "Введите пароль для установки Zapret DPI Manager:")

                if [ $? -ne 0 ]; then
                    show_message "Отменено" "Установка Zapret DPI Manager отменена пользователем."
                    exit 0
                fi
            else
                echo ""
                echo "=== ТРЕБУЮТСЯ ПРАВА АДМИНИСТРАТОРА ==="
                echo "Введите пароль для установки Zapret DPI Manager:"
                read -s SUDO_PASSWORD
                echo ""
            fi

            if [ -z "$SUDO_PASSWORD" ]; then
                if [ "$USE_ZENITY" = true ] && [ "$ZENITY_INSTALLED" = true ]; then
                    show_error "Ошибка" "Пароль не может быть пустым! Попробуйте еще раз."
                else
                    echo "ОШИБКА: Пароль не может быть пустым! Попробуйте еще раз."
                fi
                continue
            fi

            if echo "$SUDO_PASSWORD" | sudo -S true 2>/dev/null; then
                break
            else
                if [ "$USE_ZENITY" = true ] && [ "$ZENITY_INSTALLED" = true ]; then
                    show_error "Ошибка" "Неверный пароль! Попробуйте еще раз."
                else
                    echo "ОШИБКА: Неверный пароль! Попробуйте еще раз."
                fi
            fi
        done
    fi
}

# === ФУНКЦИЯ: Выполнение команд с sudo ===
run_sudo() {
    if [ -n "$SUDO_PASSWORD" ]; then
        echo "$SUDO_PASSWORD" | sudo -S "$@"
    else
        sudo "$@"
    fi
}

# === ФУНКЦИЯ: Запись файла с sudo ===
write_file_with_sudo() {
    local file_path="$1"
    local content="$2"
    local temp_file=$(mktemp)
    echo "$content" > "$temp_file"
    run_sudo cp "$temp_file" "$file_path"
    rm -f "$temp_file"
}

# === ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ===
is_steamos() {
    if command -v steamos-readonly &> /dev/null; then
        echo "Обнаружена система SteamOS"
        return 0
    elif [ -f "/etc/os-release" ] && grep -qi "steamos" /etc/os-release; then
        echo "Обнаружена система SteamOS (по os-release)"
        return 0
    else
        echo "Не SteamOS система"
        return 1
    fi
}

check_for_old_files() {
    OLD_ZAPRET_DIR="$CURRENT_HOME/zapret"
    if [ -d "$OLD_ZAPRET_DIR" ]; then
        echo "Старые файлы найдены: $OLD_ZAPRET_DIR"
        return 0
    else
        echo "Старые файлы не найдены"
        return 1
    fi
}

show_backup_dialog() {
    show_question "Обнаружены старые файлы" \
        "Обнаружены файлы от старой версии Zapret.\n\nЧто вы хотите сделать?" \
        "Сделать резервную копию" "Пропустить"

    if [ $? -eq 0 ]; then
        echo "Пользователь выбрал: Сделать резервную копию"
        return 0
    else
        echo "Пользователь выбрал: Пропустить"
        return 1
    fi
}

create_backup() {
    local backup_dir="$CURRENT_HOME/zapret_backup_$(date +%Y%m%d_%H%M%S)"
    OLD_OPT_ZAPRET="/opt/zapret"

    echo "Создание резервной копии в: $backup_dir"
    mkdir -p "$backup_dir"
    BACKUP_CREATED=true
    BACKUP_DIR="$backup_dir"

    local backed_up_files=()

    if [ -f "$OLD_OPT_ZAPRET/autohosts.txt" ]; then
        cp "$OLD_OPT_ZAPRET/autohosts.txt" "$backup_dir/" 2>/dev/null && \
            backed_up_files+=("autohosts.txt")
    fi

    if [ -f "$OLD_OPT_ZAPRET/ignore.txt" ]; then
        cp "$OLD_OPT_ZAPRET/ignore.txt" "$backup_dir/" 2>/dev/null && \
            backed_up_files+=("ignore.txt")
    fi

    if [ ${#backed_up_files[@]} -gt 0 ]; then
        local files_list=$(printf "• %s\n" "${backed_up_files[@]}")
        show_message "Резервная копия создана" \
            "Резервная копия создана в:\n$backup_dir\n\nСохраненные файлы:\n$files_list\n\nПосле установки:\n1. Откройте 'Настройки Hosts' в Zapret DPI Manager\n2. Перенесите данные:\n   • Из autohosts.txt в other2.txt\n   • Из ignore.txt в ignore.txt"
    else
        echo "Нет файлов для резервного копирования"
    fi

    return 0
}

remove_old_files() {
    echo "Начинаем удаление старых файлов..."

    local temp_script=$(mktemp)

    cat > "$temp_script" << EOF
#!/bin/bash
echo "10"
echo "# Разблокировка системы SteamOS..."
steamos-readonly disable 2>/dev/null || true
sleep 0.5

echo "30"
echo "# Остановка службы zapret..."
systemctl disable zapret 2>/dev/null || true
systemctl stop zapret 2>/dev/null || true
sleep 0.5

echo "50"
echo "# Удаление файла службы..."
rm /usr/lib/systemd/system/zapret.service 2>/dev/null || true
sleep 0.5

echo "70"
echo "# Удаление папки /opt/zapret..."
rm -r /opt/zapret 2>/dev/null || true
sleep 0.5

echo "90"
echo "# Удаление старых пользовательских файлов..."
rm -r "$CURRENT_HOME/zapret" 2>/dev/null || true
rm -r "$CURRENT_HOME/Desktop/Zapret-DPI.desktop" 2>/dev/null || true
sleep 0.5

echo "95"
echo "# Блокировка системы..."
steamos-readonly enable 2>/dev/null || true
sleep 0.5

echo "100"
echo "# Удаление старых файлов завершено"
EOF

    chmod +x "$temp_script"

    if [ "$USE_ZENITY" = true ] && [ "$ZENITY_INSTALLED" = true ]; then
        run_sudo bash "$temp_script" 2>&1 | \
        show_progress "Удаление старых файлов" "Подготовка к установке новой версии..."
    else
        echo ">>> Удаление старых файлов <<<"
        run_sudo bash "$temp_script" 2>&1 | \
        while IFS= read -r line; do
            if [[ "$line" =~ ^([0-9]+)$ ]]; then
                echo "Прогресс: ${BASH_REMATCH[1]}%"
            elif [[ "$line" =~ ^#[[:space:]]*(.+)$ ]]; then
                echo "> ${BASH_REMATCH[1]}"
            fi
        done
    fi

    rm -f "$temp_script"
    run_sudo systemctl daemon-reload 2>/dev/null || true
    echo "Старые файлы удалены"
    return 0
}

check_old_versions() {
    echo "Проверка наличия старых версий..."

    if ! check_for_old_files; then
        echo "Старые файлы не найдены, пропускаем"
        BACKUP_CREATED=false
        return 0
    fi

    echo "Старые файлы найдены"
    if ! show_backup_dialog; then
        echo "Пользователь выбрал пропустить бэкап"
        BACKUP_CREATED=false
        remove_old_files
        return 0
    fi

    echo "Пользователь выбрал сделать бэкап"
    create_backup
    remove_old_files
    return 0
}

show_final_message() {
    local backup_dir="$1"
    local backup_created="$2"

    if [ "$backup_created" = true ] && [ -n "$backup_dir" ] && [ -d "$backup_dir" ]; then
        show_message "Установка завершена" \
            "Установка Zapret DPI Manager 2.0 завершена!\n\n✅ Установлены компоненты:\n• Zapret DPI service\n• Zapret DPI Manager GUI\n• Ярлыки на рабочем столе\n\n🚀 Запуск программы:\n• Ярлык на рабочем столе\n• Меню приложений\n• Терминал: cd ~/Zapret_DPI_Manager && python3 main.py\n\n📁 Ваши старые настройки сохранены в:\n$backup_dir\n\n📝 Для восстановления настроек:\n1. Откройте 'Настройки Hosts' в Zapret DPI Manager\n2. Перенесите данные:\n   • Из autohosts.txt перенесите в other2.txt\n   • Из ignore.txt перенесите в ignore.txt\n\n❌ Удаление программы:\nОткройте Zapret DPI Manager -> Настройки -> 'Удалить Zapret'"
    else
        show_message "Установка завершена" \
            "Установка Zapret DPI Manager 2.0 завершена!\n\n✅ Установлены компоненты:\n• Zapret DPI service\n• Zapret DPI Manager GUI\n• Ярлыки на рабочем столе\n\n🚀 Запуск программы:\n• Ярлык на рабочем столе\n• Меню приложений\n• Терминал: cd ~/Zapret_DPI_Manager и python3 main.py\n\n❌ Удаление программы:\nОткройте Zapret DPI Manager -> Настройки -> 'Удалить Zapret'"
    fi
}

# === ОСНОВНАЯ ПРОГРАММА ===
exec 3>&1
exec 1> >(tee -a /tmp/zapret_install.log)
exec 2>&1

echo "=== Zapret DPI Manager установка начата: $(date) ==="
echo "Текущий пользователь: $CURRENT_USER"
echo "Домашняя директория: $CURRENT_HOME"

# Пытаемся установить zenity если нет
install_zenity_if_needed

# Приветственное окно
show_message "Zapret DPI Manager 2.0" \
    "Добро пожаловать в установку Zapret DPI Manager 2.0!\nЭта программа установит:\n• Zapret DPI сервис\n• Графический интерфейс управления\n• Ярлыки на рабочем столе\n\nНажмите OK для продолжения."

# Запрашиваем sudo доступ
echo "Запрос sudo доступа..."
get_sudo_access
echo "Sudo доступ получен"

# Проверяем и удаляем старые версии
OLD_ZAPRET_DIR="$CURRENT_HOME/zapret"
if [ -d "$OLD_ZAPRET_DIR" ]; then
    echo "Найдена старая папка zapret: $OLD_ZAPRET_DIR"
    check_old_versions
    echo "BACKUP_CREATED: $BACKUP_CREATED"
    echo "BACKUP_DIR: $BACKUP_DIR"
fi

# Проверяем наличие старой папки Zapret DPI Manager
TARGET_DIR="$CURRENT_HOME/Zapret_DPI_Manager"
if [ -d "$TARGET_DIR" ]; then
    echo "Найдена старая папка Zapret DPI Manager: $TARGET_DIR"

    show_question "Обнаружена старая версия" \
        "Обнаружена предыдущая версия Zapret DPI Manager.\n\nСоздать резервную копию и установить новую версию?" \
        "Продолжить с резервной копией" "Выйти"

    if [ $? -eq 0 ]; then
        OLD_BACKUP_DIR="${TARGET_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
        echo "Создание резервной копии в: $OLD_BACKUP_DIR"
        cp -r "$TARGET_DIR" "$OLD_BACKUP_DIR" 2>/dev/null || true
        rm -rf "$TARGET_DIR"
        show_message "Резервная копия" "Создана резервная копия:\n$OLD_BACKUP_DIR"
    else
        show_message "Отменено" "Установка отменена."
        exit 0
    fi
fi

echo "Начинаем основную установку..."

# Основной процесс установки
if ! (
    echo "5"
    echo "# Подготовка к установке..."

    echo "10"
    if is_steamos; then
        echo "# Разблокировка файловой системы SteamOS..."
        if ! run_sudo steamos-readonly disable; then
            echo "Ошибка разблокировки системы" >&2
            exit 1
        fi
        echo "Система разблокирована"
    else
        echo "# Пропуск разблокировки (не SteamOS)"
    fi

    echo "15"
    echo "# Создание временных файлов..."
    TEMP_DIR=$(mktemp -d)
    chown "$CURRENT_USER:$CURRENT_USER" "$TEMP_DIR"
    echo "Временная директория: $TEMP_DIR"

    echo "20"
    echo "# Скачивание Zapret DPI Manager..."
    ARCHIVE_URL="https://github.com/mashakulina/Zapret-DPI-for-Steam-Deck/releases/latest/download/Zapret_DPI_Manager.tar.gz"
    ARCHIVE_PATH="$TEMP_DIR/Zapret_DPI_Manager.tar.gz"

    if ! wget -q -O "$ARCHIVE_PATH" "$ARCHIVE_URL"; then
        echo "Ошибка скачивания архива" >&2
        exit 1
    fi
    echo "Архив скачан: $ARCHIVE_PATH"

    echo "25"
    echo "# Проверка скачанных файлов..."
    if ! tar -tzf "$ARCHIVE_PATH" > /dev/null 2>&1; then
        echo "Архив поврежден" >&2
        exit 1
    fi

    echo "30"
    echo "# Создание папки программы..."
    mkdir -p "$TARGET_DIR"

    echo "40"
    echo "# Распаковка файлов..."
    if ! tar -xzf "$ARCHIVE_PATH" -C "$TARGET_DIR"; then
        echo "Ошибка распаковки" >&2
        exit 1
    fi

    chown -R "$CURRENT_USER:$CURRENT_USER" "$TARGET_DIR"
    echo "Файлы распакованы в: $TARGET_DIR"

    echo "50"
    echo "# Установка системных файлов..."
    SYSTEM_SRC_DIR="$TARGET_DIR/zapret/system"
    if [ -d "$SYSTEM_SRC_DIR" ]; then
        run_sudo mkdir -p /opt/zapret
        run_sudo cp -r "$SYSTEM_SRC_DIR/"* /opt/zapret/ 2>/dev/null || true
        run_sudo chmod -R o+r /opt/zapret/
        echo "Системные файлы скопированы в /opt/zapret"
    else
        echo "Внимание: SYSTEM_SRC_DIR не найден: $SYSTEM_SRC_DIR"
    fi

    echo "60"
    echo "# Установка исполняемых файлов..."
    arch=$(uname -m)
    echo "Архитектура: $arch"
    case "$arch" in
        x86_64) bin_dir="x86_64" ;;
        i386|i686) bin_dir="x86" ;;
        armv7l|armv6l) bin_dir="arm" ;;
        aarch64) bin_dir="arm64" ;;
        *)
            echo "Неподдерживаемая архитектура: $arch" >&2
            exit 1
            ;;
    esac

    BIN_SRC_DIR="$TARGET_DIR/zapret/bins"
    if [ -d "$BIN_SRC_DIR" ]; then
        BIN_PATH="$BIN_SRC_DIR/$bin_dir/nfqws"
        if [ -f "$BIN_PATH" ]; then
            run_sudo cp "$BIN_PATH" /opt/zapret/
            run_sudo chmod +x /opt/zapret/nfqws
            echo "Бинарник скопирован: $BIN_PATH"
        else
            FOUND_BIN=$(find "$BIN_SRC_DIR" -name "nfqws" -type f 2>/dev/null | head -1)
            if [ -n "$FOUND_BIN" ]; then
                run_sudo cp "$FOUND_BIN" /opt/zapret/
                run_sudo chmod +x /opt/zapret/nfqws
                echo "Бинарник найден и скопирован: $FOUND_BIN"
            else
                echo "Внимание: бинарник nfqws не найден"
            fi
        fi
    else
        echo "Внимание: BIN_SRC_DIR не найден: $BIN_SRC_DIR"
    fi

    echo "70"
    echo "# Очистка временных файлов..."
    ZAPRET_DIR="$TARGET_DIR/zapret"
    if [ -d "$ZAPRET_DIR" ]; then
        ZAPRET_OWNER=$(stat -c '%U' "$ZAPRET_DIR")
        if [ "$ZAPRET_OWNER" = "root" ]; then
            run_sudo rm -rf "$ZAPRET_DIR"
        else
            rm -rf "$ZAPRET_DIR"
        fi
        echo "Временная папка zapret удалена"
    fi

    echo "75"
    echo "# Настройка скриптов..."
    for script in starter.sh stopper.sh; do
        if [ ! -f "/opt/zapret/$script" ]; then
            SCRIPT_PATH="$SYSTEM_SRC_DIR/$script"
            if [ -f "$SCRIPT_PATH" ]; then
                run_sudo cp "$SCRIPT_PATH" "/opt/zapret/$script"
                run_sudo chmod +x "/opt/zapret/$script"
                echo "Скрипт $script установлен"
            fi
        else
            run_sudo chmod +x "/opt/zapret/$script"
        fi
    done

    echo "80"
    echo "# Создание системной службы..."
    SERVICE_CONTENT="[Unit]
Description=zapret
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/zapret
ExecStart=/bin/bash /opt/zapret/starter.sh
ExecStop=/bin/bash /opt/zapret/stopper.sh

[Install]
WantedBy=multi-user.target"

    write_file_with_sudo "/usr/lib/systemd/system/zapret.service" "$SERVICE_CONTENT"

    run_sudo chmod 644 /usr/lib/systemd/system/zapret.service
    echo "Служба systemd создана"

    echo "85"
    echo "# Запуск службы zapret..."
    run_sudo systemctl daemon-reload
    run_sudo systemctl start zapret.service
    run_sudo systemctl enable zapret.service
    echo "Служба запущена и включена"

    sleep 2

    echo "Проверка статуса службы..."
    if run_sudo systemctl is-active zapret.service > /dev/null 2>&1; then
        echo "Служба zapret активна"
    else
        echo "Внимание: служба zapret не активна"
    fi

    echo "90"
    echo "# Создание ярлыков на рабочем столе..."
    MAIN_SCRIPT="$TARGET_DIR/main.py"
    ICON_PATH="$TARGET_DIR/ico/zapret.png"

    if [ -f "$MAIN_SCRIPT" ]; then
        DESKTOP_CONTENT="[Desktop Entry]
Encoding=UTF-8
Version=1.0
Type=Application
Name=Zapret DPI Manager
GenericName=Zapret DPI Manager
Comment=GUI Manager for Zapret DPI
Exec=python3 \"$MAIN_SCRIPT\"
Icon=${ICON_PATH:-}
Categories=Network;
Keywords=zapret;security;privacy;
Terminal=false
StartupNotify=true
StartupWMClass=ZapretDPIManager
MimeType=
X-GNOME-UsesNotifications=true
InitialPreference=9
OnlyShowIn=GNOME;XFCE;KDE;
"

        DESKTOP_PATHS=(
            "$CURRENT_HOME/Рабочий стол/Zapret_DPI_Manager.desktop"
            "$CURRENT_HOME/Desktop/Zapret_DPI_Manager.desktop"
            "$CURRENT_HOME/desktop/Zapret_DPI_Manager.desktop"
        )

        for desktop_path in "${DESKTOP_PATHS[@]}"; do
            desktop_dir=$(dirname "$desktop_path")
            if [ -d "$desktop_dir" ] && [ ! -f "$desktop_path" ]; then
                echo "$DESKTOP_CONTENT" > "$desktop_path"
                chmod 755 "$desktop_path"
                echo "Ярлык создан: $desktop_path"
            fi
        done

        APPS_DIR="$CURRENT_HOME/.local/share/applications"
        APPS_PATH="$APPS_DIR/Zapret_DPI_Manager.desktop"

        if [ ! -f "$APPS_PATH" ]; then
            mkdir -p "$APPS_DIR"
            echo "$DESKTOP_CONTENT" > "$APPS_PATH"
            chmod 644 "$APPS_PATH"
            if command -v update-desktop-database &> /dev/null; then
                update-desktop-database "$APPS_DIR" 2>/dev/null || true
            fi
            echo "Ярлык в меню приложений создан: $APPS_PATH"
        fi
    else
        echo "Внимание: основной скрипт не найден: $MAIN_SCRIPT"
    fi

    echo "95"
    echo "# Завершение установки..."
    rm -rf "$TEMP_DIR"
    echo "Временные файлы удалены"

    echo "100"
    if is_steamos; then
        echo "# Блокировка файловой системы SteamOS..."
        run_sudo steamos-readonly enable
        echo "Система заблокирована"
    else
        echo "# Пропуск блокировки (не SteamOS)"
    fi

) | show_progress "Установка Zapret DPI Manager 2.0" "Начинаем установку..."
then
    show_error "Ошибка" "Установка была прервана или произошла ошибка.\n\nПроверьте лог: /tmp/zapret_install.log"
    exit 1
fi

echo "Установка завершена успешно"

# Показываем финальное сообщение
show_final_message "$BACKUP_DIR" "$BACKUP_CREATED"

# Автозапуск GUI
show_question "Запуск программы" "Запустить Zapret DPI Manager сейчас?" "Да" "Нет"

if [ $? -eq 0 ]; then
    MAIN_SCRIPT="$TARGET_DIR/main.py"
    if [ -f "$MAIN_SCRIPT" ]; then
        echo "Запуск программы..."
        sleep 1
        cd "$TARGET_DIR" && python3 main.py &
        sleep 2

        if pgrep -f "python3.*main.py" > /dev/null; then
            echo "Программа запущена успешно"
        else
            show_error "Внимание" "Программа могла не запуститься.\nПопробуйте запустить вручную:\ncd ~/Zapret_DPI_Manager && python3 main.py"
        fi
    else
        ALT_SCRIPT="$TARGET_DIR/main_window.py"
        if [ -f "$ALT_SCRIPT" ]; then
            echo "Найден альтернативный скрипт: $ALT_SCRIPT"
            show_question "Альтернативный скрипт" "Основной скрипт не найден.\nНайден альтернативный: main_window.py\nЗапустить его?" "Да" "Нет"
            if [ $? -eq 0 ]; then
                cd "$TARGET_DIR" && python3 main_window.py &
                sleep 2
            fi
        else
            show_error "Внимание" "Основной скрипт не найден.\nПроверьте установку.\n\nПроверьте наличие файлов в:\n$TARGET_DIR/"
        fi
    fi
fi

echo "=== Установка завершена: $(date) ==="
