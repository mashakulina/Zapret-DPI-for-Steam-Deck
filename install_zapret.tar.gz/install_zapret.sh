#!/bin/bash

set -e

DECK_USER="deck"
DECK_HOME="/home/$DECK_USER"
SUDO_PASSWORD=""
BACKUP_CREATED=false
BACKUP_DIR=""

# Функция для запроса пароля sudo через zenity
get_sudo_access() {
    if ! sudo -n true 2>/dev/null; then
        while true; do
            SUDO_PASSWORD=$(zenity --password --title="Требуются права администратора" \
                                   --text="Введите пароль для установки Zapret DPI Manager:")

            # Проверяем, была ли нажата отмена
            if [ $? -ne 0 ]; then
                zenity --info --title="Отменено" \
                       --text="Установка Zapret DPI Manager отменена пользователем." \
                       --width=300
                exit 0
            fi

            # Проверяем, что пароль не пустой
            if [ -z "$SUDO_PASSWORD" ]; then
                zenity --error --title="Ошибка" \
                       --text="Пароль не может быть пустым! Попробуйте еще раз."
                continue
            fi

            # Проверяем пароль
            if echo "$SUDO_PASSWORD" | sudo -S true 2>/dev/null; then
                # Пароль верный, выходим из цикла
                break
            else
                # Пароль неверный, показываем ошибку и продолжаем цикл
                zenity --error --title="Ошибка" \
                       --text="Неверный пароль! Попробуйте еще раз."
            fi
        done
    fi
}

# Функция для выполнения команд с sudo
run_sudo() {
    echo "$SUDO_PASSWORD" | sudo -S "$@"
}

# Функция для записи файла с sudo
write_file_with_sudo() {
    local file_path="$1"
    local content="$2"

    # Создаем временный файл
    local temp_file=$(mktemp)
    echo "$content" > "$temp_file"

    # Копируем его с sudo
    run_sudo cp "$temp_file" "$file_path"

    # Очищаем
    rm -f "$temp_file"
}

# ================ ФУНКЦИЯ 1: Проверка наличия старых файлов ================
check_for_old_files() {
    OLD_ZAPRET_DIR="/home/deck/zapret"

    if [ -d "$OLD_ZAPRET_DIR" ]; then
        echo "Старые файлы найдены: $OLD_ZAPRET_DIR"
        return 0  # Найдены
    else
        echo "Старые файлы не найдены"
        return 1  # Не найдены
    fi
}

# ================ ФУНКЦИЯ 2: Диалог выбора ================
show_backup_dialog() {
    local result

    # Показываем диалог с выбором
    zenity --question \
        --title="Обнаружены старые файлы" \
        --text="Обнаружены файлы от старой версии Zapret.\n\nЧто вы хотите сделать?" \
        --width=400 \
        --height=100 \
        --ok-label="Сделать резервную копию" \
        --cancel-label="Пропустить" \
        --no-markup 2>/dev/null

    result=$?

    if [ $result -eq 0 ]; then
        echo "Пользователь выбрал: Сделать резервную копию"
        return 0  # Сделать бэкап
    else
        echo "Пользователь выбрал: Пропустить"
        return 1  # Пропустить
    fi
}

# ================ ФУНКЦИЯ 3: Создание резервной копии ================
create_backup() {
    local backup_dir="$DECK_HOME/zapret_backup_$(date +%Y%m%d_%H%M%S)"
    OLD_OPT_ZAPRET="/opt/zapret"

    echo "Создание резервной копии в: $backup_dir"

    # Создаем директорию
    mkdir -p "$backup_dir"
    BACKUP_CREATED=true
    BACKUP_DIR="$backup_dir"

    # Копируем файлы если они есть
    local backed_up_files=()

    if [ -f "$OLD_OPT_ZAPRET/autohosts.txt" ]; then
        cp "$OLD_OPT_ZAPRET/autohosts.txt" "$backup_dir/" 2>/dev/null && \
            backed_up_files+=("autohosts.txt")
    fi

    if [ -f "$OLD_OPT_ZAPRET/ignore.txt" ]; then
        cp "$OLD_OPT_ZAPRET/ignore.txt" "$backup_dir/" 2>/dev/null && \
            backed_up_files+=("ignore.txt")
    fi

    # Показываем информацию о бэкапе
    if [ ${#backed_up_files[@]} -gt 0 ]; then
        local files_list=$(printf "• %s\n" "${backed_up_files[@]}")
        zenity --info \
            --title="Резервная копия создана" \
            --text="Резервная копия создана в:
$backup_dir

Сохраненные файлы:
$files_list

После установки:
1. Откройте 'Настройки Hosts' в Zapret DPI Manager
2. Перенесите данные:
   • Из autohosts.txt в other2.txt
   • Из ignore.txt в ignore.txt" \
            --width=400 \
            --height=300 \
            --no-markup 2>/dev/null || echo "Информация о бэкапе не показана"
    else
        echo "Нет файлов для резервного копирования"
    fi

    return 0
}

# ================ ФУНКЦИЯ 4: Удаление старых файлов ================
remove_old_files() {
    echo "Начинаем удаление старых файлов..."

    # Создаем временный файл для прогресс-бара
    local temp_script=$(mktemp)

    cat > "$temp_script" << 'EOF'
#!/bin/bash
echo "10"
echo "# Разблокировка системы SteamOS..."
steamos-readonly disable 2>/dev/null || true
sleep 0.5

echo "30"
echo "# Остановка службы zapret..."
systemctl disable zapret 2>/dev/null || true
systemctl stop zapret 2>/dev/null || true
sleep 0.5

echo "50"
echo "# Удаление файла службы..."
rm /usr/lib/systemd/system/zapret.service 2>/dev/null || true
sleep 0.5

echo "70"
echo "# Удаление папки /opt/zapret..."
rm -r /opt/zapret 2>/dev/null || true
sleep 0.5

echo "90"
echo "# Удаление папки /home/deck/zapret..."
rm -r /home/deck/zapret 2>/dev/null || true
rm -r /home/deck/Desktop/Zapret-DPI.desktop 2>/dev/null || true
sleep 0.5

echo "95"
echo "# Блокировка системы..."
steamos-readonly enable 2>/dev/null || true
sleep 0.5

echo "100"
echo "# Удаление старых файлов завершено"
EOF

    # Делаем скрипт исполняемым
    chmod +x "$temp_script"

    # Запускаем прогресс-бар с удалением
    echo "$SUDO_PASSWORD" | sudo -S bash "$temp_script" 2>&1 | \
    zenity --progress \
        --title="Удаление старых файлов" \
        --text="Подготовка к установке новой версии..." \
        --percentage=0 \
        --auto-close \
        --no-cancel \
        --width=350 2>/dev/null || true

    # Очищаем
    rm -f "$temp_script"

    # Перезагружаем systemd
    echo "$SUDO_PASSWORD" | sudo -S systemctl daemon-reload 2>/dev/null || true

    echo "Старые файлы удалены"
    return 0
}

# ================ ФУНКЦИЯ 5: Основная логика проверки старых версий ================
check_old_versions() {
    echo "Проверка наличия старых версий..."

    # Шаг 1: Проверяем наличие старых файлов
    if ! check_for_old_files; then
        echo "Старые файлы не найдены, пропускаем"
        BACKUP_CREATED=false
        return 0
    fi

    # Шаг 2: Показываем диалог выбора
    echo "Показываем диалог выбора..."
    if ! show_backup_dialog; then
        # Пользователь выбрал "Пропустить"
        echo "Пользователь выбрал пропустить бэкап"
        BACKUP_CREATED=false

        # Шаг 3.2: Удаляем файлы без бэкапа
        remove_old_files
        return 0
    fi

    # Пользователь выбрал "Сделать резервную копию"
    echo "Пользователь выбрал сделать бэкап"

    # Шаг 3.1: Создаем бэкап
    create_backup

    # Шаг 4: Удаляем старые файлы
    remove_old_files

    return 0
}

# Функция для показа финального сообщения
show_final_message() {
    local backup_dir="$1"
    local backup_created="$2"

    if [ "$backup_created" = true ] && [ -n "$backup_dir" ] && [ -d "$backup_dir" ]; then
        # Вариант 1: С бэкапом
        zenity --info --title="Установка завершена" \
               --text="Установка Zapret DPI Manager 2.0 завершена!

✅ Установлены компоненты:
• Zapret DPI service
• Zapret DPI Manager GUI
• Ярлыки на рабочем столе

🚀 Запуск программы:
• Ярлык на рабочем столе
• Меню приложений (Игры или Утилиты)
• Терминал: cd ~/Zapret_DPI_Manager и python3 main.py

📁 Ваши старые настройки сохранены в:
$backup_dir

📝 Для восстановления настроек:
1. Откройте 'Настройки Hosts' в Zapret DPI Manager
2. Перенесите данные:
   • Из autohosts.txt перенесите в other2.txt
   • Из ignore.txt перенесите в ignore.txt

❌ Удаление программы:
Откройте Zapret DPI Manager -> Настройки -> 'Удалить Zapret'" \
               --width=500 \
               --height=450 \
               --no-markup
    else
        # Вариант 2: Без бэкапа
        zenity --info --title="Установка завершена" \
               --text="Установка Zapret DPI Manager 2.0 завершена!

✅ Установлены компоненты:
• Zapret DPI service
• Zapret DPI Manager GUI
• Ярлыки на рабочем столе

🚀 Запуск программы:
• Ярлык на рабочем столе
• Меню приложений (Игры или Утилиты)
• Терминал: cd ~/Zapret_DPI_Manager и python3 main.py

❌ Удаление программы:
Откройте Zapret DPI Manager -> Настройки -> 'Удалить Zapret'" \
               --width=500 \
               --height=300 \
               --no-markup
    fi
}

# ================ ОСНОВНАЯ ПРОГРАММА ================

# Логирование для отладки
exec 3>&1  # Сохраняем стандартный вывод
exec 1> >(tee -a /tmp/zapret_install.log)
exec 2>&1

echo "=== Zapret DPI Manager установка начата: $(date) ==="

# Проверяем наличие zenity
if ! command -v zenity &> /dev/null; then
    echo "Error: zenity is not installed. Please install it first."
    echo "Run: sudo pacman -S zenity"
    exit 1
fi

echo "Zenity найден"

# Показываем приветственное окно
zenity --info --title="Zapret DPI Manager 2.0" \
       --text="Добро пожаловать в установку Zapret DPI Manager 2.0!

Эта программа установит:
• Zapret DPI сервис
• Графический интерфейс управления
• Ярлыки на рабочем столе

Нажмите OK для продолжения." \
       --width=400 \
       --height=200 \
       --no-markup

echo "Приветственное окно показано"

# Запрашиваем sudo доступ
echo "Запрос sudo доступа..."
get_sudo_access
echo "Sudo доступ получен"

# Проверяем и удаляем старые версии
OLD_ZAPRET_DIR="/home/deck/zapret"
if [ -d "$OLD_ZAPRET_DIR" ]; then
    echo "Найдена старая папка zapret: $OLD_ZAPRET_DIR"
    check_old_versions
    echo "BACKUP_CREATED: $BACKUP_CREATED"
    echo "BACKUP_DIR: $BACKUP_DIR"
fi

# Проверяем наличие старой папки Zapret DPI Manager
TARGET_DIR="$DECK_HOME/Zapret_DPI_Manager"
if [ -d "$TARGET_DIR" ]; then
    echo "Найдена старая папка Zapret DPI Manager: $TARGET_DIR"
    zenity --question --title="Обнаружена старая версия" \
           --text="Обнаружена предыдущая версия Zapret DPI Manager.

Создать резервную копию и установить новую версию?" \
           --width=350 \
           --ok-label="Продолжить с резервной копией" \
           --cancel-label="Выйти"

    if [ $? -eq 0 ]; then
        OLD_BACKUP_DIR="${TARGET_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
        echo "Создание резервной копии в: $OLD_BACKUP_DIR"
        sudo -u "$DECK_USER" cp -r "$TARGET_DIR" "$OLD_BACKUP_DIR" 2>/dev/null || true
        sudo -u "$DECK_USER" rm -rf "$TARGET_DIR"
        zenity --info --title="Резервная копия" \
               --text="Создана резервная копия:
$OLD_BACKUP_DIR" \
               --width=300 \
               --no-markup
    else
        zenity --info --title="Отменено" \
               --text="Установка отменена." \
               --width=250 \
               --no-markup
        exit 0
    fi
fi

echo "Начинаем основную установку..."

# Основной процесс установки с прогресс-баром
if ! (
    echo "5"
    echo "# Подготовка к установке..."

    # Разблокировка файловой системы SteamOS
    echo "10"
    echo "# Разблокировка файловой системы SteamOS..."
    if ! run_sudo steamos-readonly disable; then
        echo "Ошибка разблокировки системы" >&2
        exit 1
    fi
    echo "Система разблокирована"

    # Создание временной директории
    echo "15"
    echo "# Создание временных файлов..."
    TEMP_DIR=$(mktemp -d)
    chown "$DECK_USER:$DECK_USER" "$TEMP_DIR"
    echo "Временная директория: $TEMP_DIR"

    # Скачивание архива
    echo "20"
    echo "# Скачивание Zapret DPI Manager..."
    ARCHIVE_URL="https://github.com/mashakulina/Zapret-DPI-for-Steam-Deck/releases/latest/download/Zapret_DPI_Manager.tar.gz"
    ARCHIVE_PATH="$TEMP_DIR/Zapret_DPI_Manager.tar.gz"

    if ! sudo -u "$DECK_USER" wget -q -O "$ARCHIVE_PATH" "$ARCHIVE_URL"; then
        echo "Ошибка скачивания архива" >&2
        exit 1
    fi
    echo "Архив скачан: $ARCHIVE_PATH"

    # Проверка архива
    echo "25"
    echo "# Проверка скачанных файлов..."
    if ! sudo -u "$DECK_USER" tar -tzf "$ARCHIVE_PATH" > /dev/null 2>&1; then
        echo "Архив поврежден" >&2
        exit 1
    fi

    # Создание целевой директории
    echo "30"
    echo "# Создание папки программы..."
    sudo -u "$DECK_USER" mkdir -p "$TARGET_DIR"

    # Распаковка архива
    echo "40"
    echo "# Распаковка файлов..."
    if ! sudo -u "$DECK_USER" tar -xzf "$ARCHIVE_PATH" -C "$TARGET_DIR"; then
        echo "Ошибка распаковки" >&2
        exit 1
    fi

    chown -R "$DECK_USER:$DECK_USER" "$TARGET_DIR"
    echo "Файлы распакованы в: $TARGET_DIR"

    # Копирование системных файлов
    echo "50"
    echo "# Установка системных файлов..."
    SYSTEM_SRC_DIR="$TARGET_DIR/zapret/system"
    if [ -d "$SYSTEM_SRC_DIR" ]; then
        run_sudo mkdir -p /opt/zapret
        run_sudo cp -r "$SYSTEM_SRC_DIR/"* /opt/zapret/ 2>/dev/null || true
        run_sudo chmod -R o+r /opt/zapret/
        echo "Системные файлы скопированы в /opt/zapret"
    else
        echo "Внимание: SYSTEM_SRC_DIR не найден: $SYSTEM_SRC_DIR"
    fi

    # Определение архитектуры и копирование бинарника
    echo "60"
    echo "# Установка исполняемых файлов..."
    arch=$(uname -m)
    echo "Архитектура: $arch"
    case "$arch" in
        x86_64) bin_dir="x86_64" ;;
        i386|i686) bin_dir="x86" ;;
        armv7l|armv6l) bin_dir="arm" ;;
        aarch64) bin_dir="arm64" ;;
        *)
            echo "Неподдерживаемая архитектура: $arch" >&2
            exit 1
            ;;
    esac

    BIN_SRC_DIR="$TARGET_DIR/zapret/bins"
    if [ -d "$BIN_SRC_DIR" ]; then
        BIN_PATH="$BIN_SRC_DIR/$bin_dir/nfqws"
        if [ -f "$BIN_PATH" ]; then
            run_sudo cp "$BIN_PATH" /opt/zapret/
            run_sudo chmod +x /opt/zapret/nfqws
            echo "Бинарник скопирован: $BIN_PATH"
        else
            FOUND_BIN=$(find "$BIN_SRC_DIR" -name "nfqws" -type f 2>/dev/null | head -1)
            if [ -n "$FOUND_BIN" ]; then
                run_sudo cp "$FOUND_BIN" /opt/zapret/
                run_sudo chmod +x /opt/zapret/nfqws
                echo "Бинарник найден и скопирован: $FOUND_BIN"
            else
                echo "Внимание: бинарник nfqws не найден"
            fi
        fi
    else
        echo "Внимание: BIN_SRC_DIR не найден: $BIN_SRC_DIR"
    fi

    # Удаление временной папки zapret
    echo "70"
    echo "# Очистка временных файлов..."
    ZAPRET_DIR="$TARGET_DIR/zapret"
    if [ -d "$ZAPRET_DIR" ]; then
        ZAPRET_OWNER=$(stat -c '%U' "$ZAPRET_DIR")
        if [ "$ZAPRET_OWNER" = "root" ]; then
            run_sudo rm -rf "$ZAPRET_DIR"
        else
            sudo -u "$DECK_USER" rm -rf "$ZAPRET_DIR"
        fi
        echo "Временная папка zapret удалена"
    fi

    # Проверка и установка скриптов
    echo "75"
    echo "# Настройка скриптов..."
    for script in starter.sh stopper.sh; do
        if [ ! -f "/opt/zapret/$script" ]; then
            SCRIPT_PATH="$SYSTEM_SRC_DIR/$script"
            if [ -f "$SCRIPT_PATH" ]; then
                run_sudo cp "$SCRIPT_PATH" "/opt/zapret/$script"
                run_sudo chmod +x "/opt/zapret/$script"
                echo "Скрипт $script установлен"
            fi
        else
            run_sudo chmod +x "/opt/zapret/$script"
        fi
    done

    # Создание службы systemd
    echo "80"
    echo "# Создание системной службы..."
    SERVICE_CONTENT="[Unit]
Description=zapret
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/zapret
ExecStart=/bin/bash /opt/zapret/starter.sh
ExecStop=/bin/bash /opt/zapret/stopper.sh

[Install]
WantedBy=multi-user.target"

    write_file_with_sudo "/usr/lib/systemd/system/zapret.service" "$SERVICE_CONTENT"

    run_sudo chmod 644 /usr/lib/systemd/system/zapret.service
    echo "Служба systemd создана"

    # Запуск службы
    echo "85"
    echo "# Запуск службы zapret..."
    run_sudo systemctl daemon-reload
    run_sudo systemctl start zapret.service
    run_sudo systemctl enable zapret.service
    echo "Служба запущена и включена"

    sleep 2

    # Проверяем статус службы
    echo "Проверка статуса службы..."
    if run_sudo systemctl is-active zapret.service > /dev/null 2>&1; then
        echo "Служба zapret активна"
    else
        echo "Внимание: служба zapret не активна"
    fi

    # Создание ярлыков
    echo "90"
    echo "# Создание ярлыков на рабочем столе..."
    MAIN_SCRIPT="$TARGET_DIR/main.py"
    ICON_PATH="$TARGET_DIR/ico/zapret.png"

    if [ -f "$MAIN_SCRIPT" ]; then
        DESKTOP_CONTENT="[Desktop Entry]
Encoding=UTF-8
Version=1.0
Type=Application
Name=Zapret DPI Manager
GenericName=Zapret DPI Manager
Comment=GUI Manager for Zapret DPI on Steam Deck
Exec=python3 \"$MAIN_SCRIPT\"
Icon=${ICON_PATH:-}
Categories=Network;
Keywords=zapret;security;privacy;
Terminal=false
StartupNotify=true
StartupWMClass=ZapretDPIManager
MimeType=
X-GNOME-UsesNotifications=true
InitialPreference=9
OnlyShowIn=GNOME;XFCE;KDE;
"

        # Ярлыки на рабочем столе
        DESKTOP_PATHS=(
            "$DECK_HOME/Рабочий стол/Zapret_DPI_Manager.desktop"
            "$DECK_HOME/Desktop/Zapret_DPI_Manager.desktop"
        )

        for desktop_path in "${DESKTOP_PATHS[@]}"; do
            desktop_dir=$(dirname "$desktop_path")
            if [ -d "$desktop_dir" ] && [ ! -f "$desktop_path" ]; then
                echo "$DESKTOP_CONTENT" | sudo -u "$DECK_USER" tee "$desktop_path" > /dev/null
                sudo -u "$DECK_USER" chmod 755 "$desktop_path"
                echo "Ярлык создан: $desktop_path"
            fi
        done

        # Ярлык в меню приложений
        APPS_DIR="$DECK_HOME/.local/share/applications"
        APPS_PATH="$APPS_DIR/Zapret_DPI_Manager.desktop"

        if [ ! -f "$APPS_PATH" ]; then
            sudo -u "$DECK_USER" mkdir -p "$APPS_DIR"
            echo "$DESKTOP_CONTENT" | sudo -u "$DECK_USER" tee "$APPS_PATH" > /dev/null
            sudo -u "$DECK_USER" chmod 644 "$APPS_PATH"
            sudo -u "$DECK_USER" update-desktop-database "$APPS_DIR" 2>/dev/null || true
            echo "Ярлык в меню приложений создан: $APPS_PATH"
        fi
    else
        echo "Внимание: основной скрипт не найден: $MAIN_SCRIPT"
    fi

    # Очистка и блокировка
    echo "95"
    echo "# Завершение установки..."
    rm -rf "$TEMP_DIR"
    echo "Временные файлы удалены"

    echo "100"
    echo "# Блокировка файловой системы..."
    run_sudo steamos-readonly enable
    echo "Система заблокирована"

) | zenity --progress \
          --title="Установка Zapret DPI Manager 2.0" \
          --text="Начинаем установку..." \
          --percentage=0 \
          --auto-close \
          --no-cancel \
          --width=400
then
    echo "Ошибка в процессе установки" >&2
    zenity --error --title="Ошибка" \
           --text="Установка была прервана или произошла ошибка.\n\nПроверьте лог: /tmp/zapret_install.log" \
           --width=350 \
           --no-markup
    exit 1
fi

# Проверяем успешность установки
echo "Установка завершена успешно"

# Показываем финальное сообщение
show_final_message "$BACKUP_DIR" "$BACKUP_CREATED"


# Автозапуск GUI
zenity --question --title="Запуск программы" \
       --text="Запустить Zapret DPI Manager сейчас?" \
       --width=300 \
       --no-markup

if [ $? -eq 0 ]; then
    MAIN_SCRIPT="$TARGET_DIR/main.py"
    if [ -f "$MAIN_SCRIPT" ]; then
        echo "Запуск программы..."

        # Даем время для завершения текущего процесса
        sleep 1

        # Запускаем от имени пользователя deck в новой сессии
        sudo -u "$DECK_USER" bash -c "cd '$TARGET_DIR' && python3 main.py" &

        # Даем время на запуск
        sleep 2

        # Проверяем, запустился ли процесс
        if pgrep -f "python3.*main.py" > /dev/null; then
            echo "Программа запущена успешно"
        else
            echo "Внимание: программа возможно не запустилась"
            zenity --warning --title="Внимание" \
                   --text="Программа могла не запуститься.\nПопробуйте запустить вручную:\ncd ~/Zapret_DPI_Manager && python3 main.py" \
                   --width=400 \
                   --no-markup
        fi
    else
        echo "Основной скрипт не найден: $MAIN_SCRIPT"
        # Ищем альтернативные пути
        ALT_SCRIPT="$TARGET_DIR/main_window.py"
        if [ -f "$ALT_SCRIPT" ]; then
            echo "Найден альтернативный скрипт: $ALT_SCRIPT"
            zenity --question --title="Альтернативный скрипт" \
                   --text="Основной скрипт не найден.\nНайден альтернативный: main_window.py\nЗапустить его?" \
                   --width=350 \
                   --no-markup
            if [ $? -eq 0 ]; then
                sudo -u "$DECK_USER" bash -c "cd '$TARGET_DIR' && python3 main_window.py" &
                sleep 2
            fi
        else
            zenity --warning --title="Внимание" \
                   --text="Основной скрипт не найден.\nПроверьте установку.\n\nПроверьте наличие файлов в:\n$TARGET_DIR/" \
                   --width=400 \
                   --no-markup
        fi
    fi
fi

echo "=== Установка завершена: $(date) ==="
